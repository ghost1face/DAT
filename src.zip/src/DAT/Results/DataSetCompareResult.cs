﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAT.Results
{
    public class DataSetCompareResult
    {
        public List<DataRowCompareResult> DataRows { get; set; }
    }
}
