﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAT.Results
{
    public class DataRowCompareResult
    {
        public List<DataPointCompareResult> DataPoints { get; set; }
    }
}
