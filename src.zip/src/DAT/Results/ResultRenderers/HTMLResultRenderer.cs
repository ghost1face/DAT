﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAT.Results.ResultRenderers
{
    class HTMLResultRenderer
    {
    }
}
