﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAT.Results
{
    public class DataCompareResults
    {
        public List<DataSetCompareResult> DataSets { get; set; }
    }
}
