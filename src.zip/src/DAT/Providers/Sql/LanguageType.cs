﻿namespace DAT.Providers.Sql
{
    public enum LanguageType
    {
        English,
        Spanish
    }
}
