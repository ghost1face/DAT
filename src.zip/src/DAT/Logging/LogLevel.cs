﻿namespace DAT.Logging
{
    public enum LogLevel
    {
        Quiet,
        Minimal,
        Detailed,
        Diagnostic
    }
}
